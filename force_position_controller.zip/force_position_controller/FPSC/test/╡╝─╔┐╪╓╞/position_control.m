function [sys,x0,str,ts]=position_control(t,x,u,flag)
switch flag
case 0
    [sys,x0,str,ts]=mdlInitializeSizes;
case 1
    sys=mdlDerivatives(t,x,u);
case 3
    sys=mdlOutputs(t,x,u);
case {2, 4, 9 }
    sys = [];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 1;
sizes.NumInputs      = 4;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 0;
sys=simsizes(sizes);
x0=[];
str=[];
ts=[];

function sys=mdlOutputs(t,x,u)
%PD����ϵ��
m=1;
kp = 1e5; % ��λ��N/m
kd = 2*0.7*(kp*m)^0.5; % ��λ��N*s/m
xd = u(1); 
x = u(3);  
dx = u(4);
% �����
F = kp*(xd-x) - kd*dx;
sys(1) = F;

