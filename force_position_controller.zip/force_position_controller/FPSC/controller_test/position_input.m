function [sys,x0,str,ts]=position_input(t,x,u,flag)
switch flag
case 0
    [sys,x0,str,ts]=mdlInitializeSizes;
case 1
    sys=mdlDerivatives(t,x,u);
% case 2
%     sys=mdlUpdate(t,x,u);
case 3
    sys=mdlOutputs(t,x,u);
case {2, 4, 9 }
    sys = [];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
end

function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates  = 0;   
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 2;
sizes.NumInputs      = 0;
sizes.DirFeedthrough = 0;
sizes.NumSampleTimes = 1;
sys=simsizes(sizes);
x0=[];
str=[];
ts=[0.01 0];
end

%不用就注释调，同上flag
% function sys=mdlUpdate(t,x,u)
% end

function sys=mdlOutputs(t,x,u)
x0=sin(t);
dx0=cos(t);
sys(1)=x0;
sys(2)=dx0;
end


