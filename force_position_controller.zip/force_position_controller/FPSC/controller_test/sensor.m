function [sys,x0,str,ts]=sensor(t,x,u,flag)
    switch flag
    case 0
        [sys,x0,str,ts]=mdlInitializeSizes;
%     case 1
%         sys=mdlDerivatives(t,x,u);
     case 2
         sys=mdlUpdate(t,x,u);
    case 3
        sys=mdlOutputs(t,x,u);
    case {1, 4, 9 }
        sys = [];
    otherwise
        error(['Unhandled flag = ',num2str(flag)]);
    end
end

function [sys,x0,str,ts]=mdlInitializeSizes
    sizes = simsizes;
    sizes.NumContStates  = 0;   
    sizes.NumDiscStates  = 0;
    sizes.NumOutputs     = 1;
    sizes.NumInputs      = 2;
    sizes.DirFeedthrough = 1;
    sizes.NumSampleTimes = 0;
    sys=simsizes(sizes);
    x0=[];
    str=[];
    ts=[];
end

% function sys=mdlDerivatives(t,x,u)
% 
% end
% 
function sys=mdlUpdate(t,x,u)
    sys = x;
end

function sys=mdlOutputs(t,x,u)
    %比例参数
    %质量
    k = 1;
    m = 1;
    t = 0.5;
    td = 0;
    e1 = u(1) - t;
    e2 = u(2) - td;
    if( e1 < 0 )
        e1 = 0;
    end
    e2 = abs(e2);
    f = k * e1 + m * e2;
    sys = f;
end
