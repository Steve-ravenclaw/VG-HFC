function [sys,x0,str,ts]=sensor(t,x,u,flag)
    switch flag
    case 0
        [sys,x0,str,ts]=mdlInitializeSizes;
%     case 1
%         sys=mdlDerivatives(t,x,u);
%      case 2
%          sys=mdlUpdate(t,x,u);
    case 3
        sys=mdlOutputs(t,x,u);
    case {1,2, 4, 9 }
        sys = [];
    otherwise
        error(['Unhandled flag = ',num2str(flag)]);
    end
end

function [sys,x0,str,ts]=mdlInitializeSizes
    sizes = simsizes;
    sizes.NumContStates  = 0;   
    sizes.NumDiscStates  = 0;
    sizes.NumOutputs     = 1;
    sizes.NumInputs      = 2;
    sizes.DirFeedthrough = 1;
    sizes.NumSampleTimes = 1;
    sys=simsizes(sizes);
    x0=[];
    str=[];
    ts=[0 0];
end

% function sys=mdlDerivatives(t,x,u)
% 
% end


function sys=mdlOutputs(t,x,u)
    %比例参数
    k = 1000; 
    m = 1;
    t = 0.65;
    td = 0;
    e1 =  t - u(1);

    if( e1 < 0 )
        f = 0;
    else
         f = k * e1 ;
    end
    sys = f;
end
