function [sys,x0,str,ts]=laypunov_ctrl2(t,x,u,flag)
    switch flag
    case 0
        [sys,x0,str,ts]=mdlInitializeSizes;
%     case 1
%         sys=mdlDerivatives(t,x,u);
    case 2
        sys=mdlUpdate(t,x,u);
    case 3
        sys=mdlOutputs(t,x,u);
    case {1, 4, 9 }
        sys = [];
    otherwise
        error(['Unhandled flag = ',num2str(flag)]);
    end
end

function [sys,x0,str,ts]=mdlInitializeSizes
    sizes = simsizes;
    sizes.NumContStates  = 0;   
    sizes.NumDiscStates  = 2;
    sizes.NumOutputs     = 2;
    sizes.NumInputs      = 2;
    sizes.DirFeedthrough = 0;
    sizes.NumSampleTimes = 0;
    sys=simsizes(sizes);
    x0=[1;1];
    str=[];
    ts=[];
end

% function sys=mdlDerivatives(t,x,u)
% 
% end

function sys=mdlUpdate(t,x,u)
    sys(1) = u(1);
    sys(2) = u(2);
end

function sys=mdlOutputs(t,x,u)
    a = x(1) + u(1) ;
    b = x(2) + u(2) ;
    sys = [a; b];
end
