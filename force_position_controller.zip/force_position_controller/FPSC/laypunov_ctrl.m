function [sys,x0,str,ts]=laypunov_ctrl(t,x,u,flag)
    switch flag
    case 0
        [sys,x0,str,ts]=mdlInitializeSizes;
    case 1
        sys=mdlDerivatives(t,x,u);
%     case 2
%         sys=mdlUpdate(t,x,u);
    case 3
        sys=mdlOutputs(t,x,u);
    case {2, 4, 9 }
        sys = [];
    otherwise
        error(['Unhandled flag = ',num2str(flag)]);
    end
end

function [sys,x0,str,ts]=mdlInitializeSizes
    sizes = simsizes;
    sizes.NumContStates  = 6;   
    sizes.NumDiscStates  = 0;
    sizes.NumOutputs     = 2;
    sizes.NumInputs      = 4;
    sizes.DirFeedthrough = 1;
    sizes.NumSampleTimes = 0;
    sys=simsizes(sizes);
    x0=[1;1;1;1; 0 ;0];  %num5为误差
    str=[];
    ts=[];
end

function sys=mdlDerivatives(t,x,u)
    %u(1)为x,u(2)为dx,u(3)为xd,u(4)为dxd
    xt = [u(3);u(4)];
    %学习率
    n1 = 0.1;
    n2 = 0.1;
    n3 = 0.1;
    n4 = 0.1;
    k = 10;
    %模型参数
    a = 1;
    b = 1;
    c = 1;
    d = 1;
    %状态误差
    e = [ u(3)-u(1);u(4)-u(2)];
    %更新参数
    da = n1 * e(2);
    db = n2 * xt(1) * e(2);
    dc = n3 * xt(2) * e(2);
    dd = n4 * xt(2) * e(1);
    
    de = -k * e + [(d-x(4)) * xt(2); (a-x(1)) + (b-x(2)) * xt(1) + (c-x(3)) * xt(2)];
 
    sys = [da;db;dc;dd;de(1);de(2)];
end

% function sys=mdlUpdate(t,x,u)
% 
% end

function sys=mdlOutputs(t,x,u)
    sys(1) = x(5) + u(1) ;
    sys(2) = x(6) + u(2) ;
%  %u(1)为x,u(2)为dx,u(3)为xd,u(4)为dxd
%     xt = [u(3);u(4)];
%     %学习率
%     n1 = 0.1;
%     n2 = 10;
%     n3 = 100;
%     n4 = 1;
%     k = 10;
%     %模型参数
%     a = 1;
%     b = 1;
%     c = 1;
%     d = 1;
%     %状态误差
%     e = [u(1)-u(3);u(4)-u(2)];
%     u= -k * e + [(d-x(4)) * xt(2); (a-x(1)) + (b-x(2)) * xt(1) + (c-x(3)) * xt(2)];
%     sys = u;

end
