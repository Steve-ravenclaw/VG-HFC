clear;
clc;
%% 参数初始化
lr=0.1;%学习速率
beta=0.05;%动量因子
x=[0,0,0]';%初始化输入
nn=6;%隐含层节点数

%RBF网络3-6-1结构初始化参数
ci=30*ones(3,nn);%节点基函数中心向量
bi=40*ones(nn,1);%节点基函数方差
w=10*ones(nn,1); %输出层权重

h=zeros(nn,1);%隐藏层输出向量

ci_1=ci;ci_3=ci_1;ci_2=ci_1;
bi_1=bi;bi_2=bi_1;bi_3=bi_2;
w_1=w;w_2=w_1;w_3=w_1;

u_1=0;y_1=0;
ec=[0,0,0]';%误差变化率ec,e,ecc
error_1=0;error_2=0;error=0;

% PID 初始参数设置
kp0 = 2;        
ki0 = 0.01;     
kd0 = 0.01;
flag=0;%控制模式flag=0 PID&RBF;flag=1 PID

kp_1=kp0;
kd_1=kd0;
ki_1=ki0;  

%pid参数学习率
kp_lr=10;
kd_lr=10;
ki_lr=10;
ts=0.01;
%%
for t = 1:1:300
   time(t)=t*ts;
%    input(t)= 1;%系统参考输入
   input(t) = sin(10 * time(t));
   y(t)=(-0.1*y_1+u_1)/(20+y_1^2);%系统输出
   %% 前向传播
   %1.计算每个节点RBF的输出
   for j=1:1:nn
      h(j)=exp(-norm(x-ci(:,j))^2/(2*bi(j)*bi(j)));
   end
   %2. RBF网络输出
   ym(t)=w'*h;    
   %% 反向传播
   %1. 输出权重更新计算
   d_w=0*w;
   for j=1:1:nn
      d_w(j)=lr*(y(t)-ym(t))*h(j);
   end
   w=w_1+d_w+beta*(w_1-w_2);
   %2. 节点基函数方差更新
   d_bi=0*bi;
   for j=1:1:nn
      d_bi(j)=lr*(y(t)-ym(t))*w(j)*h(j)*(bi(j)^-3)*norm(x-ci(:,j))^2;
   end
   bi=bi_1+ d_bi+beta*(bi_1-bi_2);
   %3. 节点中心更新
   for j=1:1:nn
     for i=1:1:3
      d_ci(i,j)=lr*(y(t)-ym(t))*w(j)*h(j)*(x(i)-ci(i,j))*(bi(j)^-2);
     end
   end
   ci=ci_1+d_ci+beta*(ci_1-ci_2);
  
  %% 系统雅可比矩阵计算
   yu=0;
   for  j=1:1:nn
      yu=yu+w(j)*h(j)*(-x(1)+ci(1,j))/bi(j)^2; 
   end
   dyout(t)=yu;
   %% PID控制器参数修改
   error(t)=input(t)-y(t);
   kp(t)=kp_1+kp_lr*error(t)*dyout(t)*ec(1);
   kd(t)=kd_1+kd_lr*error(t)*dyout(t)*ec(2);
   ki(t)=ki_1+ki_lr*error(t)*dyout(t)*ec(3);  
   if kp(t)<0
      kp(t)=0;
   end
   if kd(t)<0
      kd(t)=0;
   end
   if ki(t)<0
      ki(t)=0;
   end
   switch flag
       case 0
       case 1 
            kp(t)=kp0;
            ki(t)=ki0;     
            kd(t)=kd0;
   end
   du(t)=kp(t)*ec(1)+kd(t)*ec(2)+ki(t)*ec(3); %增量PID控制
   u(t)=u_1+du(t);

   %Return of parameters
   x(1)=du(t);
   x(2)=y(t);
   x(3)=y_1;
   
   u_1=u(t);
   y_1=y(t);
   
   ci_3=ci_2;
   ci_2=ci_1;
   ci_1=ci;
   
   bi_3=bi_2;
   bi_2=bi_1;
   bi_1=bi;
   
   w_3=w_2;
   w_2=w_1;
   w_1=w;
   
   ec(1)=error(t)-error_1;
   ec(2)=error(t)-2*error_1+error_2;
   ec(3)=error(t);  
   
   error_2=error_1;
   error_1=error(t);
   
   kp_1=kp(t);
   kd_1=kd(t);
   ki_1=ki(t);
end
%% 绘图
figure(1);
plot(time,input,'b',time,y,'r');
xlabel('time(s)');ylabel('r(t),y(t)');
title('RBF&PID控制器下系统输出')
figure(2);
plot(time,error);
xlabel('times(s)');ylabel('error(t)');
title('RBF&PID控制器下系统误差');
figure(3);
plot(time,kp,time,ki,time,kd);
xlabel('times(s)');
ylabel('kp,ki,kd');
title('kp,ki,kd整定');
legend('kp','ki','kd');
grid on;


