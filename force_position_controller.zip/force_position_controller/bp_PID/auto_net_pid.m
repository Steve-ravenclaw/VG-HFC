clear all;
clc
x = [0,0,0]'; %定义输入矩阵
xiteP = 0.4;  %定义学习速率
xiteI = 0.35; 
xiteD = 0.4;

wkp_1 = 0.1; %初始化权重
wki_1 = 0.1;
wkd_1 = 0.1;

erro_1 = 0; %初始化误差
erro_2 = 0;
y_1 = 0;y_2 = 0; %初始化被控对象模型
u_1 = 0;u_2 = 0;

ts = 0.001; %定义时间步长

for k=1:1:100 %循环迭代
    time(k) = k*ts; %时间为K*ts总时间也就是1
    yd(k) = 200 + 10 * sin(50 * pi * ts * k); %目标值
%     if k==100
%         y(k) = 3*u_1+0.2; %当迭代到100次加入扰动0.2
%     else
        y(k) = 3*u_1; %被控对象模型

    erro(k) = yd(k)-y(k); %获取误差
    
    wkp(k) = wkp_1+xiteP*erro(k)*u_1*x(1); %更新权重
    wki(k) = wki_1+xiteI*erro(k)*u_1*x(2);
    wkd(k) = wkd_1+xiteD*erro(k)*u_1*x(3);
    K = 0.12; %定义比例系数
    
    x(1) = erro(k)-erro_1; %给输入矩阵赋值
    x(2) = erro(k);
    x(3) = erro(k)-2*erro_1+erro_2;
    
    wadd(k) = abs(wkp(k))+abs(wki(k))+abs(wkd(k)); %将权重求和
    w11(k) = wkp(k)/wadd(k); %得出P
    w22(k) = wki(k)/wadd(k); %I
    w33(k) = wkd(k)/wadd(k); %D
    w = [w11(k),w22(k),w33(k)];
    
    u(k) = u_1 + K*w*x; %增量式PID
    erro_2 = erro_1; %e(k-2)
    erro_1 = erro(k);%e(k-1)
    
    u_1 = u(k)
    
    wkp_1 = wkp(k); %w1(k-1)
    wkd_1 = wkd(k); 
    wki_1 = wki(k);
end

figure(1);
plot(time,yd,'r',time,y,'k','linewidth',2);%显示被控模型曲线和设定曲线
legend
xlabel('time(s)');ylabel('yd,y'); 
legend('ideal position','position tracking');
figure(2);
plot(time,u,'r','linewidth',2); %显示输入PID输出曲线
xlabel('time(s)');ylabel('Control input');
figure(3);
plot(time,w11,'g',time,w22,'r',time,w33,'b','linewidth',2); %显示PID参数调整曲线
xlabel('time(s)');ylabel('PID');
legend('P','I','D');
