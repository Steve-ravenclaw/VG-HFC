clear;
clc;

S = 1; %signal type

IN = 4; H = 5; OUT = 3;   %NN structure

%parameter initialization 
%wi = 0.5 * rands(H,IN);
%x迁移网络
wi =[-0.221777196404939,-0.272936556160284,-0.000287378452185087,0.565283407727676;0.525584864942147,0.384851471305848,0.551540022791673,0.271274796699710;-0.0540590641821341,0.321872319936191,-0.0881621327163410,0.0910515457672990;-0.619722354752375,0.274607681927946,-0.332176307259480,-0.392622848033277;0.450115944704720,-0.0636427129150047,0.304191117211240,0.598043936478630];
wi_1 = wi;
dwi_1 = zeros(H,IN);

%wo = 0.5 * rands(OUT,H);
wo = [0.358489250808270,-0.524241601318298,0.416743436751009,0.409385055803831,-0.207572159483099;-0.344327730928788,0.0820934720956777,0.193562263663453,0.459344094803302,-0.128394698378778;-0.324904027976981,-0.633090754237204,-0.402542354994434,0.507619378777279,-0.673520902032001]
wo_1 = wo;
dwo = zeros(OUT,H);
dwo_1 = dwo;

error_1 = 0;
error_2 = 0;

y_1 = 0;
u_1 = 0;
du_1 = 0;

xite = 0.2;
pro = 0.4;
xite1 = 0.5;

%taget trace
ts = 0.001;
for k=1:1:100
    time(k) = k * ts;
%     if S == 1
%         rin(k) = 1.0;
%     else
%         rin(k) = sin(2*pi*ts*k);
%     end
%     rin(k) =   sin(50 * pi * ts * k);
    rin(k) =   1;
    %对于目标非常大的数据，需要进行归一化处理。
    rin(k) = rin(k) /200;
    
    %unline model 
    %a(k) = 1.2 * (1-0.8 * exp (-0.1*k));
    %yout(k) = a(k)*y_1/(1+y_1^2) + u_1;
    error(k) = rin(k) - y_1;

    %input
    xi = [rin(k), y_1,error(k),1];

    x1 = error(k)-error_1;
    x2 = error(k);
    x3 = error(k) -2*error_1+ error_2;
    epid = [x1; x2; x3];                                          %3x1

    %first prediction
    I =  wi * xi';                                                %5x1
    for j = 1:1:H   %激活函数
        oh(j) = (exp(I(j))-exp(-I(j)))/ (exp(I(j)) + exp(-I(j))); %1x5
    end
    
    %second prediction
    K = wo * oh';                                                  %3x1 
    for j =1:1:OUT
        oo(j) = exp(K(j))/(exp(K(j)) + exp(-K(j))) ;               %1x3
    end
    
    kp(k) = oo(1);
    ki(k) = oo(2);
    kd(k) = oo(3);
    
    du(k) =  kp(k) *  x1 +  ki(k) *  x2 +  kd(k) *  x3 ;
    u(k) = u_1 + du(k);
    
    %反向传递
    %dyu(k) = sign((yout(k) - y_1)/(du(k) - du_1 + 0.00001)); %防止分母为0；
    dyu(k) = 1;
    
    %output layer
    for j=1:1:OUT
        dno(j) = 2/(exp(K(j))+exp(-K(j)))^2;       %out层激活函数 1x3
    end
    for j=1:1:OUT
        delta3(j) = error(k) * dyu(k) * epid(j) * dno(j);    %1x3
    end
    for j=1:1:OUT
            dwo(j,:) =  xite * delta3(j) * oh + pro * dwo_1(j,:);
    end
    wo = wo_1 + xite1 * dwo;
    
    %hidden layer
    for j=1:1:H
        do(j) = 4/(exp(I(j))+exp(-I(j)))^2;        %1x5
    end
    delta5 = delta3 * wo ;
    for j=1:1:H
        delta5(j) = delta5(j) * do(j);
    end
    for j = 1:1:H
        dwi(j,:) = xite * delta5(j) * xi + pro * dwi_1(j,:);
    end
    wi = wi_1 + xite1 * dwi;
    
    %parameter update
    du_1 = du(k);
    u_1 = u(k);
    y_1 = u(k);
    
    error_2 = error_1;
    error_1 = error(k);
    
    wi_1 = wi;
    wo_1 = wo;
    dwi_1 = dwi;
    dwo_1 = dwo;
    
end

figure(1)
plot(time,rin*200,'r',time, u*200,'k','linewidth',2);
xlabel('time(s)');ylabel('yd,y ,error');
legend('ideal position','position tracking','error tracking');
figure(2)
plot(time,kp,'g',time,ki,'r',time,kd,'b','linewidth',2); %显示PID参数调整曲线
xlabel('time(s)');ylabel('PID');
legend('P','I','D');

