clc 
clear 
theta1 = [10.220 -27.881 -10.855  58.902 87.556 68.721 ]'  %-47.220

theta2 = [10.220 -30.601 7.049  119.947 82.556 81.631 ]' 

theta3 = [53.687 16.740 51.927 180.992 77.278 94.540 ]' 
theta4 = [53.687 30.191 31.927 180.992 43.308 94.540 ]' 

pi = 3.14159265
theta1 = theta1 /180 * pi
theta2 = theta2 /180 * pi
theta4 = theta4 /180 * pi
theta3 = theta3  /180 * pi
q1 = struct('JointName',{'1_join' '2_join' '3_join' '4_join' '5_join' '6_join'},'JointPosition',{theta1(1) theta1(2) theta1(3) theta1(4) theta1(5) theta1(6)})
q2 = struct('JointName',{'1_join' '2_join' '3_join' '4_join' '5_join' '6_join'},'JointPosition',{theta2(1) theta2(2) theta2(3) theta2(4) theta2(5) theta2(6)})

q3 = struct('JointName',{'1_join' '2_join' '3_join' '4_join' '5_join' '6_join'},'JointPosition',{theta3(1) theta3(2) theta3(3) theta3(4) theta3(5) theta3(6)})
q4 = struct('JointName',{'1_join' '2_join' '3_join' '4_join' '5_join' '6_join'},'JointPosition',{theta4(1) theta4(2) theta4(3) theta4(4) theta4(5) theta4(6)})


% %添加图层
figure('name','robot');
robot=importrobot('M_20IA_35_1.0.SLDASM.urdf');
show(robot);
title("6R robot");


endEffector = "6_Link";
currentRobotJConfig = homeConfiguration(robot) %获取当前关节配置
jointInit = currentRobotJConfig;
taskInit = getTransform(robot,q1 ,endEffector)

% taskFinal = trvec2tform([0,0,0])
% ik = inverseKinematics('RigidBodyTree',robot);
% ik.SolverParameters.AllowRandomRestart = false;
% weights = [1 1 1 1 1 1];
% jointFinal = ik(endEffector,taskFinal,weights,q1)
% show(robot,jointFinal,"PreservePlot",false)%false 不留下重影，true留下

% hold on;
% show(robot,q1,"PreservePlot",false)%false 不留下重影，true留下
% show(robot,q1,"PreservePlot",false)%false 不留下重影，true留下
% show(robot,q4,"PreservePlot",false)%false 不留下重影，true留下
% show(robot,q3,"PreservePlot",false)%false 不留下重影，true留下
% show(robot,q2,"PreservePlot",false)%false 不留下重影，true留下
   
    
    size1 = 28;
    Ta1 = zeros(size1,6);
    Ta1(:,1) = linspace(theta1(1),theta2(1),size1);
    Ta1(:,2) = linspace(theta1(2),theta2(2),size1);
    Ta1(:,3) = linspace(theta1(3),theta2(3),size1);
    Ta1(:,4) = linspace(theta1(4),theta2(4),size1);
    Ta1(:,5) = linspace(theta1(5),theta2(5),size1);
    Ta1(:,6) = linspace(theta1(6),theta2(6),size1);
    
%     robot.DataFormat='column';%数据格式为列，row为行；
%     hold on;
%     for i = 1:size1
%         drawnow
%         show(robot,Ta1(i,:)',"PreservePlot",false);%false 不留下重影，true留下
%         poseNow = getTransform(robot, Ta1(i,:)', endEffector);%正运动学
%         plot3(poseNow(1,4), poseNow(2,4), poseNow(3,4),'b.','MarkerSize',15)%末端轨迹
%     end
%     
%     
    size1 = 60
    Ta2 = zeros(size1,6);
    Ta2(:,1) = linspace(theta2(1),theta3(1),size1);
    Ta2(:,2) = linspace(theta2(2),theta3(2),size1);
    Ta2(:,3) = linspace(theta2(3),theta3(3),size1);
    Ta2(:,4) = linspace(theta2(4),theta3(4),size1);
    Ta2(:,5) = linspace(theta2(5),theta3(5),size1);
    Ta2(:,6) = linspace(theta2(6),theta3(6),size1);
%     for i = 1:size1
%         drawnow
%         show(robot,Ta2(i,:)',"PreservePlot",false);%false 不留下重影，true留下
%         poseNow = getTransform(robot, Ta2(i,:)', endEffector);%正运动学
%         plot3(poseNow(1,4), poseNow(2,4), poseNow(3,4),'b.','MarkerSize',15)%末端轨迹
%     end
    
    size1 = 50
    Ta3 = zeros(size1,6);
    Ta3(:,1) = linspace(theta3(1),theta4(1),size1);
    Ta3(:,2) = linspace(theta3(2),theta4(2),size1);
    Ta3(:,3) = linspace(theta3(3),theta4(3),size1);
    Ta3(:,4) = linspace(theta3(4),theta4(4),size1);
    Ta3(:,5) = linspace(theta3(5),theta4(5),size1);
    Ta3(:,6) = linspace(theta3(6),theta4(6),size1);
%     for i = 1:size1
%         drawnow
%         show(robot,Ta3(i,:)',"PreservePlot",false);%false 不留下重影，true留下
%         poseNow = getTransform(robot, Ta3(i,:)', endEffector);%正运动学
%         plot3(poseNow(1,4), poseNow(2,4), poseNow(3,4),'b.','MarkerSize',15)%末端轨迹
%     end
   

    

%——————————————————q1-q2
robot.DataFormat='struct';%数据格式为列，row为行；
task1 = getTransform(robot,q1,endEffector);
task2  = getTransform(robot,q2,endEffector);
task3  = getTransform(robot,q3,endEffector);
task4  = getTransform(robot,q4,endEffector);
distance = norm(tform2trvec(task1)-tform2trvec(task2)) + norm(tform2trvec(task2)-tform2trvec(task3)) +  norm(tform2trvec(task3)-tform2trvec(task4)); %两变换之间的欧式距离
timeStep = 0.1;%秒，时间插值步长
toolSpeed = 0.1;% m/s ，工具坐标速度
initTime = 0;	% 起始时间
finalTime = (distance/toolSpeed) - initTime;% 计算运行时间
trajTimes = initTime:timeStep:finalTime;	% 插值时间
timeInterval = [trajTimes(1); trajTimes(end)]; % 起始时间区
% 
ctrlpoints = [theta1'; theta2'; theta3';  theta4']'
%jointConfigArray = cubicpolytraj(ctrlpoints,timeInterval,trajTimes);        %生成三阶多项式轨迹
jointWaypoints = bsplinepolytraj(ctrlpoints,timeInterval,trajTimes)          %B样条插值
% 
% robot.DataFormat='column';%数据格式为列，row为行；
% hold on;
% for i =  1:size(jointWaypoints,2)
%     drawnow
%     show(robot,jointWaypoints(:,i),"PreservePlot",false);%false 不留下重影，true留下
%     poseNow = getTransform(robot, jointWaypoints(:,i), endEffector);%正运动学
%     plot3(poseNow(1,4), poseNow(2,4), poseNow(3,4),'b.','MarkerSize',15)%末端轨迹
% end

plot(2)
Ta = [Ta1;Ta2;Ta3];
color = ['r' 'g' 'b'  'c'  'k' 'm'];
desc = ['j1'; 'j2'; 'j3';  'j4' ; 'j5'; 'j6'];
hold on 
for i=1:6
     h(i) =  plot(linspace(0,1,size(Ta,1)),Ta(:,i), color(i));
     type = [color(i)  ' -.'];
     plot(linspace(0,1,size(jointWaypoints,2)),jointWaypoints(i,:),type); 
    
end
legend(h,desc)

robot.DataFormat = "column"
for i=1:size(jointWaypoints,2)
    task = getTransform(robot,jointWaypoints(:,i) ,endEffector);
    theta_x = atan2(task(3,2),task(3,3));
    theta_y = atan2(task(3,1),sqrt(task(3,2)^2 + task(3,3)^2 ) );
    theta_z = atan2(task(1,1), task(2,1));
    tasks1(:,i) = [task(1,4),task(2,4),task(3,4),theta_x,theta_y,theta_z];
end

Ta  = Ta'   
for i=1:size(Ta,2)
    task = getTransform(robot,Ta(:,i) ,endEffector);
    theta_x = atan2(task(3,2),task(3,3));
    theta_y = atan2(task(3,1),sqrt(task(3,2)^2 + task(3,3)^2 ) );
    theta_z = atan2(task(1,1), task(2,1));
    tasks2(:,i) = [task(1,4),task(2,4),task(3,4),theta_x,theta_y,theta_z];
end

figure(3)
hold on 

desc = ['x'; 'y'; 'z';  'α' ; 'β'; 'γ'];
for i=1:6
     h(i) =  plot(linspace(0,1,size(tasks2,2)),tasks2(i,:), color(i));
     type = [color(i)  ' -.'];
     plot(linspace(0,1,size(tasks1,2)),tasks1(i,:),type); 
    
end
legend(h,desc)

% 
% subplot (1,2,1)
% hold on 
% for i=1:6
%      plot(linspace(0,1,size(Ta,1)),Ta(:,i), color(i),'DisplayName',desc(i,:));
% end
% legend
% subplot (1,2,2)
% hold on 
% for i=1:6
%     type = [color(i)  ' -.'];
%     plot(linspace(0,1,size(jointWaypoints,2)),jointWaypoints(i,:),type,'DisplayName',desc(i,:));  
% end
% legend




