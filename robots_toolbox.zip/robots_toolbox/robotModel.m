clc;
clear all;

%添加图层
figure('name','robot');

%导入机器人
robot=importrobot('M_20IA_35_1.0.SLDASM.urdf');
show(robot);

title("6R robot");


%numJoints = numel(currentRobotJConfig); %获得关节轴数
currentRobotJConfig = homeConfiguration(robot) %获取当前关节配置

%设置工具坐标系：单击机械臂、关节或坐标系可得到名称
endEffector = "6_Link";

%获取位姿变换矩阵
% trvec2tform([0.4,0,0.6]) 位移变换矩阵
% axang2tform([0 1 0 pi])  旋转变换矩阵
jointInit = currentRobotJConfig;
taskInit = getTransform(robot,jointInit,endEffector);
taskFinal = trvec2tform([0.4,0,0.6]) * axang2tform([0 1 0 pi]);

%机器人逆运动学对象，rigidBodyTree根据关节之间的转换在机器人模型中指定机器人运动学约束。
ik = inverseKinematics('RigidBodyTree',robot);
ik.SolverParameters.AllowRandomRestart = false;
weights = [1 1 1 1 1 1];
jointFinal = ik(endEffector,taskFinal,weights,jointInit);

%规划轨迹
distance = norm(tform2trvec(taskInit)-tform2trvec(taskFinal)); %两变换之间的欧式距离
timeStep = 0.1;%秒，时间插值步长
toolSpeed = 0.1;% m/s ，工具坐标速度
initTime = 0;	% 起始时间
finalTime = (distance/toolSpeed) - initTime;% 计算运行时间
trajTimes = initTime:timeStep:finalTime;	% 插值时间
timeInterval = [trajTimes(1); trajTimes(end)]; % 起始时间区间

%正运动轨迹规划
%taskWaypoints 位姿变换矩阵；taskVelocities 速度
[taskWaypoints,taskVelocities] = transformtraj(taskInit,taskFinal,timeInterval,trajTimes)


%逆运动轨迹规划
%struct2doubleArray
index = struct2table(jointFinal);
jointFinalArray = wrapToPi(index.JointPosition);
index = struct2table(jointInit);
jointInitArray = wrapToPi(index.JointPosition);

ctrlpoints = [jointInitArray';jointFinalArray']';
jointConfigArray = cubicpolytraj(ctrlpoints,timeInterval,trajTimes);        %生成三阶多项式轨迹
jointWaypoints = bsplinepolytraj(jointConfigArray,timeInterval,trajTimes);  %B样条插值

%轨迹绘制
robot.DataFormat='column';%数据格式为列，row为行；
hold on;
for i = 1:size(jointWaypoints,2)
    drawnow
    show(robot,jointWaypoints(:,i),"PreservePlot",false);%false 不留下重影，true留下
    poseNow = getTransform(robot, jointWaypoints(:,i), endEffector);%正运动学
    plot3(poseNow(1,4), poseNow(2,4), poseNow(3,4),'b.','MarkerSize',15)%末端轨迹
end

