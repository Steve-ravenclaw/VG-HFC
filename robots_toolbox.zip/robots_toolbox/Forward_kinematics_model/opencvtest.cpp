#include <opencv2/opencv.hpp>
#include <iostream>
#include <math.h>
#include <stdio.h>
#include <iomanip>
 
using namespace cv;
using namespace std;
 
double pi = 3.1415926;

Mat Robot_forward(vector<double> &theta)
{
    // 定义机器人DH参数
    double a1 = 160,a2 = 790,a3 = 150;
    double d4 = 860;
    // 计算T06
    double c23 = cos((theta[1]+theta[2]) * PI / 180);
    double s23 = sin((theta[1]+theta[2]) * PI / 180);
    double c1 = cos(theta[0] * PI / 180); double s1 = sin(theta[0] * PI / 180);
    double c2 = cos(theta[1] * PI / 180); double s2 = sin(theta[1] * PI / 180);
    double c3 = cos(theta[2] * PI / 180); double s3 = sin(theta[2] * PI / 180);
    double c4 = cos(theta[3] * PI / 180); double s4 = sin(theta[3] * PI / 180);
    double c5 = cos(theta[4] * PI / 180); double s5 = sin(theta[4] * PI / 180);
    double c6 = cos(theta[5] * PI / 180); double s6 = sin(theta[5] * PI / 180);

    double r11 = c1*(c23*(c4*c5*c6 - s4*s5) - s23*s5*c5) + s1*(s4*c5*c6 + c4*s6);
    double r21 = s1*(c23*(c4*c5*c6 - s4*s6) - s23*s5*c6) - c1*(s4*c5*c6 + c4*s6);
    double r31 = -s23*(c4*c5*c6 - s4*s6) - c23*s5*c6;
    double r12 = c1*(c23*(-c4*c5*c6 - s4*c6) + s23*s5*s6) + s1*(c4*c6 - s4*c5*s6);
    double r22 = s1*(c23*(-c4*c5*c6 - s4*c6) + s23*s5*s6) - c1*(c4*c6 - s4*c5*s6);
    double r32 = -s23*(-c4*c5*c6 - s4*c6) + c23*s5*s6;
    double r13 = -c1*(c23*c4*s5 + s23*c5) - s1*s4*s5;
    double r23 = -s1*(c23*c4*s5 + s23*c5) + c1*s4*s5;
    double r33 = s23*c4*s5 - c23*c5;
    double px = c1*(a2*c2 + a3*c23 - d4*s23);
    double py = s1*(a2*c2 + a3*c23 - d4*s23);
    double pz = -a3*s23 - a2*s2 - d4*c23;

    Mat T06 = (Mat_<double>(4,4) << r11,r12,r13,px,r21,r22,r23,py,r31,r32,r33,pz,0,0,0,1);
    return T06;
}

int main(int argc,char *argv[])
{
    vector<double> image1_thetad= {27.620,-44.329,-39.077,117.121,10.879,4.185};
    Mat T06 = Robot_forward(image1_theta);
    std::cout  << fixed << setprecision(8);
    std::cout << T06 << endl;
    return 0;
}
