% DrawSpline.m文件
function [] = drawSpline(n, k, P, NodeVector)

if size(P, 1) == 2
    % B样条的绘图函数
    % 已知n+1个控制顶点P(i), k次B样条，P是2*(n+1)矩阵存控制顶点坐标, 节点向量NodeVector
    plot(P(1, 1:n+1), P(2, 1:n+1),...
                    'o','LineWidth',1,...
                    'MarkerEdgeColor','k',...
                    'MarkerFaceColor','g',...
                    'MarkerSize',6);
    grid on;
    line(P(1, 1:n+1), P(2, 1:n+1));   
    Nik = zeros(n+1, 1);
    for u = 0 : 0.005 : 1-0.005
        for i = 0 : 1 : n
            Nik(i+1, 1) = baseFunction(i, k , u, NodeVector);
        end
        p_u = P * Nik;
        if u == 0
            tempx = p_u(1,1);
            tempy = p_u(2,1);
            line([tempx p_u(1,1)], [tempy p_u(2,1)] ,...
                'Marker','.','LineStyle','-', 'Color',[.3 .6 .9], 'LineWidth',3);
        else
            line([tempx p_u(1,1)], [tempy p_u(2,1)] ,...
                'Marker','.','LineStyle','-', 'Color',[.3 .6 .9], 'LineWidth',3);
            tempx = p_u(1,1);
            tempy = p_u(2,1);
        end
    end
    
    
elseif size(P, 1) == 3
    % B样条的绘图函数
    % 已知n+1个控制顶点P(i), k次B样条，P是3*(n+1)矩阵存控制顶点坐标, 节点向量NodeVector
    plot3(P(1, 1:n+1), P(2, 1:n+1), P(3, 1:n+1),...
                    'o','LineWidth',1,...
                    'MarkerEdgeColor','k',...
                    'MarkerFaceColor','g',...
                    'MarkerSize',5);
     
    
    line(P(1, 1:n+1), P(2, 1:n+1),  P(3, 1:n+1));   
    Nik = zeros(n+1, 1);
    for u = 0 : 0.005 : 1-0.005
        for i = 0 : 1 : n
            Nik(i+1, 1) = baseFunction(i, k , u, NodeVector);
        end
        p_u = P * Nik;
        if u == 0
            tempx = p_u(1,1);
            tempy = p_u(2,1);
            tempz = p_u(3,1);
            line([tempx p_u(1,1)], [tempy p_u(2,1)] , [tempz p_u(3,1)] ,...
                'Marker','.','LineStyle','-', 'Color',[.3 .6 .9], 'LineWidth',1);
        else
            line([tempx p_u(1,1)], [tempy p_u(2,1)] , [tempz p_u(3,1)] ,...
                'LineStyle','-', 'Color','blue', 'LineWidth',1);
            tempx = p_u(1,1);
            tempy = p_u(2,1);
            tempz = p_u(3,1);
        end
    end
    
    xlabel('x label');
    ylabel('y label');
    zlabel('z label');
    grid on;
    xmin =-10 ;
    xmax =70;
    ymin = 30;
    ymax = 102;
    zmin =-10;
    zmax =70;
    title('三维曲线','color','b');
    legend('初始轨迹','优化轨迹');
    axis([xmin xmax ymin ymax zmin zmax]); % 设置坐标轴在指定的区间
    
else 
    
    
    disp(" size(P,1) ！= 2 / 3 ")
    
end

end
