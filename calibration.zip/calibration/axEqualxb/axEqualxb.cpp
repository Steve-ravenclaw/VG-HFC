#include <vector>
#include <iostream>
#include <opencv2/opencv.hpp>
#include <fstream>

void Navy_HandEye(cv::Mat Hcg, std::vector<cv::Mat> Hgij, std::vector<cv::Mat> Hcij)
{
    CV_Assert(Hgij.size() == Hcij.size());
    int nStatus = Hgij.size();

    cv::Mat Rgij(3, 3, CV_64FC1);
    cv::Mat Rcij(3, 3, CV_64FC1);

    cv::Mat alpha1(3, 1, CV_64FC1);
    cv::Mat beta1(3, 1, CV_64FC1);
    cv::Mat alpha2(3, 1, CV_64FC1);
    cv::Mat beta2(3, 1, CV_64FC1);
    cv::Mat A(3, 3, CV_64FC1);
    cv::Mat B(3, 3, CV_64FC1);

    cv::Mat alpha(3, 1, CV_64FC1);
    cv::Mat beta(3, 1, CV_64FC1);
    cv::Mat M(3, 3, CV_64FC1, cv::Scalar(0));

    cv::Mat MtM(3, 3, CV_64FC1);
    cv::Mat veMtM(3, 3, CV_64FC1);
    cv::Mat vaMtM(3, 1, CV_64FC1);
    cv::Mat pvaM(3, 3, CV_64FC1, cv::Scalar(0));

    cv::Mat Rx(3, 3, CV_64FC1);

    cv::Mat Tgij(3, 1, CV_64FC1);
    cv::Mat Tcij(3, 1, CV_64FC1);

    cv::Mat eyeM = cv::Mat::eye(3, 3, CV_64FC1);

    cv::Mat tempCC(3, 3, CV_64FC1);
    cv::Mat tempdd(3, 1, CV_64FC1);

    cv::Mat C;
    cv::Mat d;
    cv::Mat Tx(3, 1, CV_64FC1);

    //Compute rotation
    if (Hgij.size() == 2) // Two (Ai,Bi) pairs
    {
        cv::Rodrigues(Hgij[0](cv::Rect(0, 0, 3, 3)), alpha1);
        cv::Rodrigues(Hgij[1](cv::Rect(0, 0, 3, 3)), alpha2);
        cv::Rodrigues(Hcij[0](cv::Rect(0, 0, 3, 3)), beta1);
        cv::Rodrigues(Hcij[1](cv::Rect(0, 0, 3, 3)), beta2);

        alpha1.copyTo(A.col(0));
        alpha2.copyTo(A.col(1));
        (alpha1.cross(alpha2)).copyTo(A.col(2));

        beta1.copyTo(B.col(0));
        beta2.copyTo(B.col(1));
        (beta1.cross(beta2)).copyTo(B.col(2));

        Rx = A*B.inv();

    }
    else // More than two (Ai,Bi) pairs
    {
        for (int i = 0; i < nStatus; i++)
        {
            Hgij[i](cv::Rect(0, 0, 3, 3)).copyTo(Rgij);
            Hcij[i](cv::Rect(0, 0, 3, 3)).copyTo(Rcij);

            cv::Rodrigues(Rgij, alpha);
            cv::Rodrigues(Rcij, beta);

            M = M + beta*alpha.t();
        }

        MtM = M.t()*M;
        eigen(MtM, vaMtM, veMtM);

        pvaM.at<double>(0, 0) = 1 / sqrt(vaMtM.at<double>(0, 0));
        pvaM.at<double>(1, 1) = 1 / sqrt(vaMtM.at<double>(1, 0));
        pvaM.at<double>(2, 2) = 1 / sqrt(vaMtM.at<double>(2, 0));

        Rx = veMtM*pvaM*veMtM.inv()*M.t();
    }

    //Computer Translation
    for (int i = 0; i < nStatus; i++)
    {
        Hgij[i](cv::Rect(0, 0, 3, 3)).copyTo(Rgij);
        Hcij[i](cv::Rect(0, 0, 3, 3)).copyTo(Rcij);
        Hgij[i](cv::Rect(3, 0, 1, 3)).copyTo(Tgij);
        Hcij[i](cv::Rect(3, 0, 1, 3)).copyTo(Tcij);

        tempCC = eyeM - Rgij;
        tempdd = Tgij - Rx * Tcij;

        C.push_back(tempCC);
        d.push_back(tempdd);
    }

    Tx = (C.t()*C).inv()*(C.t()*d);

    Rx.copyTo(Hcg(cv::Rect(0, 0, 3, 3)));
    Tx.copyTo(Hcg(cv::Rect(3, 0, 1, 3)));
    Hcg.at<double>(3, 0) = 0.0;
    Hcg.at<double>(3, 1) = 0.0;
    Hcg.at<double>(3, 2) = 0.0;
    Hcg.at<double>(3, 3) = 1.0;
}
