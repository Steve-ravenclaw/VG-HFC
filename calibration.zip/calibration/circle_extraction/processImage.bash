folder="./material/"
softfiles=$(ls $folder)
for sfile in ${softfiles}
do 
   #echo "soft: ${sfile}"
   ./build/Demo  ${folder}${sfile}
done
