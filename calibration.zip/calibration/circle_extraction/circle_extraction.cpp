#include <opencv2/opencv.hpp>
#include <iostream>
#include <math.h>
#include <stdio.h>
#include <opencv2/calib3d/calib3d.hpp>
 
using namespace cv;
using namespace std;
 
Mat src_img, binary_img, dst_img;


int main(int argc,char *argv[])
{
	src_img = imread(argv[1], IMREAD_GRAYSCALE); 
	//灰度读取，在读入图像的同时进行色彩转换，这可以提高运行速度并减少内存的使用
	if (src_img.empty())
	{
                printf("could not load the image...\n");
		return -1;
	}
	namedWindow("原图", CV_WINDOW_AUTOSIZE);
        imshow("原图", src_img);
 
	// 图像二值化
	threshold(src_img, binary_img, 0, 255, THRESH_BINARY | THRESH_OTSU);
        imshow("二值图像", binary_img);
 
        dst_img = binary_img;
	// 形态学操作
        Mat kernel = getStructuringElement(MORPH_RECT, Size(5,5), Point(-1, -1));              //构建形态学操作的结构元
        morphologyEx(dst_img, dst_img, MORPH_OPEN, kernel, Point(-1, -1));                 //开操作
        //imshow("开操作", dst_img);

        kernel = getStructuringElement(MORPH_RECT, Size(5, 5), Point(-1, -1));   //构建形态学操作的结构元
        morphologyEx(dst_img, dst_img, MORPH_CLOSE, kernel, Point(-1, -1));       //闭操作
        imshow("闭操作", dst_img);
 

 
	// 寻找轮廓
        vector< vector<Point> > contours;                         //提取轮廓（轮廓号，轮廓点集）
        vector<Vec4i> hireachy;                                   //hierarchy向量内每一个元素的4个int型变量,分别表示第i个轮廓的后一个轮廓、前一个轮廓、父轮廓、内嵌轮廓的索引编号
        //CHAIN_APPROX_SIMPLE仅保存轮廓的拐点信息
        //CHAIN_APPROX_NONE 保存物体边界上所有连续的轮廓点到contours向量内
        findContours(dst_img, contours, hireachy, RETR_TREE, CHAIN_APPROX_NONE, Point());
        drawContours(dst_img, contours, -1,Scalar(255),1);
        imshow("counters", dst_img);

	Mat result_img = Mat::zeros(src_img.size(), CV_8UC3);     // 创建与原图同大小的黑色背景
        Point2f circle_center;              //定义圆心坐标

        Mat circle_img = src_img.clone();
        cvtColor(circle_img, circle_img, COLOR_GRAY2BGR);                    //灰度图转化为彩色图

        for (int t = 0; t < contours.size(); ++t)
	{
		// 面积过滤
		double area = contourArea(contours[t]);     //计算点集所围区域的面积
                double arc_length = arcLength(contours[t], true);         //计算点集所围区域的周长
                if (area < 250 || arc_length < 65)            //晒选出轮廓面积大于100的轮廓
			continue;
                if (area > 630 || arc_length > 100)
                        continue;
		// 横纵比过滤
		Rect rect = boundingRect(contours[t]);            // 求点集的最小直立外包矩形
		float ratio = float(rect.width) / float(rect.height);        //求出宽高比
 
                if (ratio < 1.1 && ratio > 0.9)       //因为圆的外接直立矩形肯定近似于一个正方形，因此宽高比接近1.0
		{ 
                        drawContours(result_img, contours, t, Scalar(0, 0, 255), -1, 8, Mat(), 0, Point());   // 在黑色背景图上画出圆，注意其中参数-1的意义
			printf("圆的面积: %f\n", area);
			printf("圆的周长 : %f\n", arc_length);
			int x = rect.x + rect.width / 2;
			int y = rect.y + rect.height / 2;
                        circle_center = Point2f(x, y);          //得到圆心坐标
                      
			char temp[16];
                        sprintf(temp,"%.0f,%.0f",circle_center.x,circle_center.y); //打印当前坐标值
			circle(result_img, circle_center, 2, Scalar(0, 255, 255), 2, 8, 0);  
                        circle(circle_img, circle_center, 2, Scalar(0, 0, 255), 2, 8, 0);    //在原图上画出圆心
                        putText(circle_img,temp,circle_center,cv::FONT_HERSHEY_SIMPLEX,0.45,Scalar(0,0,255),1);

		}
	}


        //imshow("结果", result_img);
	imshow("最终结果", circle_img);
 
	waitKey(0);
	return 0;
}
