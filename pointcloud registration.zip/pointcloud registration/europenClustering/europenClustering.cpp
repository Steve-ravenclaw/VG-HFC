#include <pcl/io/pcd_io.h>
#include <pcl/segmentation/extract_clusters.h>
#include <pcl/visualization/cloud_viewer.h>
#include <string>

using namespace std;

typedef pcl::PointXYZ PointT;

int main(int argc, char** argv)
{
	pcl::PointCloud<PointT>::Ptr cloud_in(new pcl::PointCloud<PointT>);

	pcl::PCDReader reader;
	pcl::PCDWriter writer;
	//---------------------------------
	//-------------加载点云-------------
	//---------------------------------
        if (reader.read(argv[1], *cloud_in) < 0)
	{
		PCL_ERROR("点云文件不存在！\a\n");
		return -1;
	}
        float num = 2;
        if (argc == 3)
        {
            num = atof(argv[2]);
        }

	/// 定义颜色数组，用于可视化
	float colors[] = {
	255, 0,   0,   // red 		1
	0,   255, 0,   // green		2
	0,   0,   255, // blue		3
	255, 255, 0,   // yellow	4
	0,   255, 255, // light blue5
	255, 0,   255, // magenta   6
	255, 128, 0,   // orange	8
	255, 153, 255, // pink		9
	51,  153, 255, //			10
	153, 102, 51,  //			11
	128, 51,  153, //			12
	153, 153, 51,  //			13
	163, 38,  51,  //			14
	204, 153, 102, //			15
	204, 224, 255, //			16
	128, 179, 255, //			17
	206, 255, 0,   //			18
	255, 204, 204, //			19
	204, 255, 153, //			20
	};

	//---------------------------------
	//------------欧式聚类--------------
	//---------------------------------
	/// 创建kd树
	pcl::search::KdTree<PointT>::Ptr tree(new pcl::search::KdTree<PointT>);
	tree->setInputCloud(cloud_in);

	/// 设置分割参数
	vector<pcl::PointIndices> cluster_indices;
	pcl::EuclideanClusterExtraction<PointT> ec;
        ec.setClusterTolerance(num);	//设置近邻搜索的半径
        ec.setMinClusterSize(99);	//设置最小聚类点数
	ec.setMaxClusterSize(999999);	//设置最大聚类点数
	ec.setSearchMethod(tree);
	ec.setInputCloud(cloud_in);
	ec.extract(cluster_indices);

	//----- 可视化1/3-----↓
	pcl::visualization::PCLVisualizer::Ptr viewer(new pcl::visualization::PCLVisualizer("3D viewer"));

	int v1(0);
	viewer->createViewPort(0.0, 0.0, 0.5, 1.0, v1); //设置第一个视口在X轴、Y轴的最小值、最大值，取值在0-1之间
        viewer->setBackgroundColor(1.0, 1.0, 1.0, v1);
	viewer->addText("cloud_in", 10, 10, "v1 text", v1);
	viewer->addPointCloud<PointT>(cloud_in, "cloud_in", v1);
	viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 2, "cloud_in", v1);
        viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_COLOR, 255,0,0, "cloud_in", v1);

	int v2(0);
	viewer->createViewPort(0.5, 0.0, 1.0, 1.0, v2);
        viewer->setBackgroundColor(1.0, 1.0, 1.0, v2);
	viewer->addText("cloud_cluster", 10, 10, "v2 text", v2);
	//-----可视化1/3-----↑

	/// 执行欧式聚类分割，并保存分割结果
	int j = 0;
	for (vector<pcl::PointIndices>::const_iterator it = cluster_indices.begin(); it != cluster_indices.end(); ++it)
	{
		pcl::PointCloud<PointT>::Ptr cloud_cluster(new pcl::PointCloud<PointT>);

		for (vector<int>::const_iterator pit = it->indices.begin(); pit != it->indices.end(); pit++)
		cloud_cluster->points.push_back(cloud_in->points[*pit]);
		cloud_cluster->width = cloud_cluster->points.size();
		cloud_cluster->height = 1;
		cloud_cluster->is_dense = true;

		stringstream ss;
		ss << "tree_" << j + 1 << ".pcd";
		writer.write<PointT>(ss.str(), *cloud_cluster, true);
		cout << "-----" << ss.str() << "详情-----" << endl;
		cout << *cloud_cluster << endl;
	
		//-----可视化2/3-----↓
		viewer->addPointCloud<PointT>(cloud_cluster, ss.str(), v2);
		viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 2, ss.str(), v2);
		viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_COLOR, colors[j*3] / 255, colors[j*3+1] / 255, colors[j*3 + 2] / 255, ss.str(), v2);
		//-----可视化2/3-----↑

		j++;
	}



	//-----可视化3/3-----↓
	while (!viewer->wasStopped())
	{
		viewer->spinOnce(100);
	}
        //-----可视化3/3-----↑

	return 0;
}

