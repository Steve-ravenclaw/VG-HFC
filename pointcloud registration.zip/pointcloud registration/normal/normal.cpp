#include <omp.h>
#include <iostream>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl/features/normal_3d_omp.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <boost/thread/thread.hpp>


using namespace std;

int main(int argc, char** argv)
{
	pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZ>);
	pcl::PointCloud<pcl::Normal>::Ptr cloud_normals(new pcl::PointCloud<pcl::Normal>);//存储输出数据

	pcl::io::loadPCDFile(argv[1], *cloud);
	

       //NormalEstimationOMP本质与NormalEstimation相同，但是可以使用多线程来加速计算。
        pcl::NormalEstimationOMP<pcl::PointXYZ, pcl::Normal> ne;//创建法线估计向量
	//ne.setNumberOfThreads(omp_get_max_threads());
        ne.setNumberOfThreads(4);
	ne.setInputCloud(cloud);	

	//创建一个空的KdTree对象，并把它传递给法线估计向量
	//基于给出的输入数据集，KdTree将被建立
	pcl::search::KdTree<pcl::PointXYZ>::Ptr tree(new pcl::search::KdTree<pcl::PointXYZ>());//创建一个空的KdTree对象，并把它传递给法线估计向量，基于给出的输入数据集，KdTree将被建立
	ne.setSearchMethod(tree);

	//设置视点，官网上的pcl::flipNormalTowardsViewpoint (const PointT &point, float vp_x, float vp_y, float vp_z, Eigen::Vector4f &normal)是对“一个已知点”的法线进行手动定向
        ne.setViewPoint(-10, -10, -10);

	//设置搜索半径,半径单位为毫米
//        ne.setRadiusSearch(1);
	//
	
        if(argc == 4){
                ne.setKSearch(atoi(argv[2]));
        }else if(argc == 3){
                ne.setRadiusSearch(atof(argv[2]));
        }else{
                ne.setKSearch(20);
        }

	
	
	ne.compute(*cloud_normals);
	
        //保存具有法线信息的点云文件
        pcl::PCDWriter writer;
        writer.write<pcl::Normal> ("../cloud_normal.pcd", *cloud_normals, false);

//	//可视化
//	boost::shared_ptr<pcl::visualization::PCLVisualizer> m_viewer(new pcl::visualization::PCLVisualizer("normal"));
	
//	int v1(0);
//	m_viewer->createViewPort(0.0, 0.0, 0.5, 1.0, v1);
//	m_viewer->addCoordinateSystem(0.1, "v1",v1);
//	m_viewer->setBackgroundColor(128.0 / 255.0, 138.0 / 255.0, 135.0 / 255.0, v1);
//
//	m_viewer->addPointCloud(cloud, color, "cloud1", v1);

//	int v2(0);
//	m_viewer->createViewPort(0.5, 0.0, 1.0, 1.0, v2);
//        m_viewer->addCoordinateSystem(0.1,"v2",v2);
//	m_viewer->setBackgroundColor(128.0 / 255.0, 138.0 / 255.0, 135.0 / 255.0, v2);

//	//显示点云及其法线
//	pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> Cap_Cloud_Point(cloud, 255, 0, 0);
//        //m_viewer->addPointCloud(cloud, Cap_Cloud_Point, "cloud2", v2);
//        m_viewer->addPointCloudNormals<pcl::PointXYZ, pcl::Normal>(cloud, cloud_normals, 2, 0.01, "normals", v2); //显示点云法线，第三个参数是法线显示的个数(每2个点显示1个)，第四个参数是法线的长度(此处为0.01)
	
        //-------------------------- 法线可视化 --------------------------
        boost::shared_ptr<pcl::visualization::PCLVisualizer> viewer(new pcl::visualization::PCLVisualizer("3D Viewer")); //创建视窗对象，定义标题栏名称“3D Viewer”
        viewer->setBackgroundColor(255.0 / 255.0, 255.0 / 255.0, 255.0 / 255.0);
        viewer->addPointCloud<pcl::PointXYZ>(cloud, "original_cloud");	//将点云添加到视窗对象中，并定义一个唯一的ID“original_cloud”
        viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_COLOR, 1, 0, 0.5, "original_cloud"); //点云附色，三个字段，每个字段范围0-1
        viewer->addPointCloudNormals<pcl::PointXYZ, pcl::Normal>(cloud, cloud_normals, 20, 15, "normals");	//每十个点显示一个法线，长度为0.05
        viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_COLOR, 0, 0, 1, "normals");

        while (!viewer->wasStopped())
	{
                viewer->spinOnce(100);
	}
	return 0;
}

