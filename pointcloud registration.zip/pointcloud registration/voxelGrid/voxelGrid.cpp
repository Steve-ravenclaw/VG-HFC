#include <iostream>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/filters/approximate_voxel_grid.h>
#include <pcl/visualization/pcl_visualizer.h>

int main(int argc, char** argv)
{
	// pcl::PCLPointCloud2::Ptr cloud(new pcl::PCLPointCloud2());
	// pcl::PCLPointCloud2::Ptr cloud_filtered(new pcl::PCLPointCloud2());
	pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZ>);
	pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_filtered(new pcl::PointCloud<pcl::PointXYZ>);



	// Fill in the cloud data
	pcl::PCDReader reader;
	// Replace the path below with the path where you saved your file 
	reader.read(argv[1], *cloud);

	// Create the filtering object
	// pcl::VoxelGrid<pcl::PCLPointCloud2> sor;
	// pcl::VoxelGrid<pcl::PointXYZI> sor;
    // pcl::ApproximateVoxelGrid和pcl::VoxelGrid
    // 两者区别为第一种速度快，但是精度低，损失了原始点云的局部形态精细度。
	pcl::VoxelGrid<pcl::PointXYZ> sor;

    
	sor.setInputCloud(cloud);                 //输入源点云
        sor.setLeafSize(5.0f, 5.0f, 5.0f);     //设置体素大小，leaf_size分别为lx、ly、lz的长宽高
    // inline Eigen::Vector3f getLeafSize ();     // 获取每个体素的大小
	// sor.setDownsampleAllData(true);        //设置下采样的维度，默认false, 只对XYZ进行下采样；true为对所有维度下采样
	sor.filter(*cloud_filtered);              //执行下采样

        std::cout << "cloud size:"<< cloud->points.size() << "cloud_filtered size:" << cloud_filtered->points.size() <<endl;

	pcl::PCDWriter writer;
	writer.write("../less.pcd", *cloud_filtered);
	
	// Visualization
   	 pcl::visualization::PCLVisualizer viewer ("voxelGrid demo");
    	// Create two vertically separated viewports
    	int v1 (0);
    	int v2 (1);
    	viewer.createViewPort (0.0, 0.0, 0.5, 1.0, v1);
    	viewer.createViewPort (0.5, 0.0, 1.0, 1.0, v2);
    	
    	// The color we will be using
        float bckgr_gray_level = 1.0;  // white
    	float txt_gray_lvl = 1.0 - bckgr_gray_level;
    	
	// Original point cloud is white
        pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> cloud_color_h (cloud, (int) 100 * txt_gray_lvl, (int) 100 * txt_gray_lvl,
                                                                               (int) 100 * txt_gray_lvl);
    	
    	viewer.addPointCloud (cloud, cloud_color_h, "cloud_v1", v1);
    	
    	pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> cloud_filtered_color_h (cloud_filtered, 20, 180, 20);
    	viewer.addPointCloud (cloud_filtered, cloud_filtered_color_h, "cloud_filtered_v2", v2);

	 // Adding text descriptions in each viewport
        viewer.addText ("black: Original point cloud\n", 10, 15, 16, txt_gray_lvl, txt_gray_lvl, txt_gray_lvl, "icp_info_1", v1);
        viewer.addText ("green: downsample point cloud\n", 10, 15, 16, txt_gray_lvl, txt_gray_lvl, txt_gray_lvl, "icp_info_2", v2);
   	 
   	 
    // Set background color
    viewer.setBackgroundColor (bckgr_gray_level, bckgr_gray_level, bckgr_gray_level, v1);
    viewer.setBackgroundColor (bckgr_gray_level, bckgr_gray_level, bckgr_gray_level, v2);

    // Set camera position and orientation
    viewer.setCameraPosition (-3.68332, 2.94092, 5.71266, 0.289847, 0.921947, -0.256907, 0);
    viewer.setSize (1280, 1024);  // Visualiser window size

	 while (!viewer.wasStopped ()){
	 	 viewer.spinOnce (1000);
	 }

	return 0;
}

