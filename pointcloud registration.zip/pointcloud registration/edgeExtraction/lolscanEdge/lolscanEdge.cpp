#include <iostream>
#include <algorithm>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl/visualization/cloud_viewer.h>

void BoundaryExtraction(pcl::PointCloud<pcl::PointXYZ>::Ptr cloud, pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_boundary, int resolution)
{
        pcl::PointXYZ px_min = *std::min_element(cloud->begin(), cloud->end(), [](pcl::PointXYZ pt1, pcl::PointXYZ pt2) {return pt1.x < pt2.x; });
        pcl::PointXYZ px_max = *std::max_element(cloud->begin(), cloud->end(), [](pcl::PointXYZ pt1, pcl::PointXYZ pt2) {return pt1.x < pt2.x; });

        float delta_x = (px_max.x - px_min.x) / resolution;
        float min_y = INT_MAX, max_y = -INT_MAX;
        std::vector<int> indexs_x(2 * resolution);
        std::vector<std::pair<float, float>> minmax_x(resolution, { INT_MAX,-INT_MAX });
        for (size_t i = 0; i < cloud->size(); ++i)
        {
                int id = (cloud->points[i].x - px_min.x) / delta_x;
                if (cloud->points[i].y < minmax_x[id].first)
                {
                        minmax_x[id].first = cloud->points[i].y;
                        indexs_x[id] = i;
                }
                else if (cloud->points[i].y > minmax_x[id].second)
                {
                        minmax_x[id].second = cloud->points[i].y;
                        indexs_x[id + resolution] = i;
                }
        }

        pcl::PointXYZ py_min = *std::min_element(cloud->begin(), cloud->end(), [](pcl::PointXYZ pt1, pcl::PointXYZ pt2) {return pt1.y < pt2.y; });
        pcl::PointXYZ py_max = *std::max_element(cloud->begin(), cloud->end(), [](pcl::PointXYZ pt1, pcl::PointXYZ pt2) {return pt1.y < pt2.y; });

        float delta_y = (py_max.y - py_min.y) / resolution;
        float min_x = INT_MAX, max_x = -INT_MAX;
        std::vector<int> indexs_y(2 * resolution);
        std::vector<std::pair<float, float>> minmax_y(resolution, { INT_MAX,-INT_MAX });
        for (size_t i = 0; i < cloud->size(); ++i)
        {
                int id = (cloud->points[i].y - py_min.y) / delta_y;
                if (cloud->points[i].x < minmax_y[id].first)
                {
                        minmax_y[id].first = cloud->points[i].x;
                        indexs_y[id] = i;
                }
                else if (cloud->points[i].x > minmax_y[id].second)
                {
                        minmax_y[id].second = cloud->points[i].x;
                        indexs_y[id + resolution] = i;
                }
        }

        pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_xboundary(new pcl::PointCloud<pcl::PointXYZ>);
        pcl::copyPointCloud(*cloud, indexs_x, *cloud_xboundary);
        pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_yboundary(new pcl::PointCloud<pcl::PointXYZ>);
        pcl::copyPointCloud(*cloud, indexs_y, *cloud_yboundary);
        *cloud_boundary = *cloud_xboundary + *cloud_yboundary;
}

void visualCloud(pcl::PointCloud<pcl::PointXYZ>::Ptr cloud, pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_boundary){
    pcl::visualization::PCLVisualizer viewer("edge Viewer"); //创建视窗对象，定义标题栏名称“3D Viewer”
    int v1 (0);
    int v2 (1);
    // The color we will be using
    float bckgr_gray_level = 1.0;  // Black
    float txt_gray_lvl = 1.0 - bckgr_gray_level;
    viewer.createViewPort (0.0, 0.0, 0.5, 1.0, v1);
    viewer.createViewPort (0.5, 0.0, 1.0, 1.0, v2);

    // Original point cloud is white
    pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> cloud_color_h (cloud, (int) 255 * txt_gray_lvl, (int) 255 * txt_gray_lvl,
                                                                           (int) 255 * txt_gray_lvl);
    viewer.addPointCloud (cloud, cloud_color_h, "cloud_v1", v1);

    pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> cloud_boundary_color_h (cloud_boundary, 20, 180, 20);  //blue
    viewer.addPointCloud (cloud_boundary, cloud_boundary_color_h, "cloud_boundary_v2", v2);


    // Set background color
    viewer.setBackgroundColor (bckgr_gray_level, bckgr_gray_level, bckgr_gray_level, v1);
    viewer.setBackgroundColor (bckgr_gray_level, bckgr_gray_level, bckgr_gray_level, v2);


    while (!viewer.wasStopped())
    {
            viewer.spinOnce(100);
    }
}

int main(int argc, char* argv[])
{
        pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZ>);
        pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_boundary(new pcl::PointCloud<pcl::PointXYZ>);
        pcl::io::loadPCDFile(argv[1], *cloud);

        BoundaryExtraction(cloud, cloud_boundary, atoi(argv[2]));
        pcl::io::savePCDFile("../boundary.pcd", *cloud_boundary);
        visualCloud(cloud, cloud_boundary);

        return EXIT_SUCCESS;
}
