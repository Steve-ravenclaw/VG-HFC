#include <iostream>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl/filters/statistical_outlier_removal.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/console/time.h>   // TicToc

int main (int argc, char** argv)
{
    
	pcl::PointCloud<pcl::PointXYZ>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZ>);
	pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_filtered (new pcl::PointCloud<pcl::PointXYZ>);
	pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_outtered (new pcl::PointCloud<pcl::PointXYZ>);

	// Fill in the cloud data
	pcl::PCDReader reader;
	// Replace the path below with the path where you saved your file
	reader.read<pcl::PointXYZ> (argv[1], *cloud);

	//cerr
	std::cerr << "Cloud before filtering: " << std::endl;
	std::cerr << *cloud << std::endl;

	// Create the filtering object
	pcl::StatisticalOutlierRemoval<pcl::PointXYZ> sor;   //创建统计滤波器对象
	sor.setInputCloud (cloud);                           //设置输入的点云
        sor.setMeanK (50);                                   //设置KNN的k值
	sor.setStddevMulThresh (1.0);                        //设置标准偏差乘数为1.0
	sor.filter (*cloud_filtered);                        //执行滤波

	//cerr
	std::cerr << "Cloud after filtering: " << std::endl;
	std::cerr << *cloud_filtered << std::endl;

	pcl::PCDWriter writer;
	writer.write<pcl::PointXYZ> ("../inliers.pcd" , *cloud_filtered, false);

	//获取离群点
	sor.setNegative (true);
	sor.filter (*cloud_outtered);
	writer.write<pcl::PointXYZ> ("../outliers.pcd" , *cloud_outtered, false);
    
    	// Visualization
	pcl::visualization::PCLVisualizer viewer ("statisticallFilter demo");
	// Create two vertically separated viewports
	int v1 (0);
	int v2 (1);
	int v3 (2);
	viewer.createViewPort (0.0, 0.0, 0.3333, 1.0, v1);
	viewer.createViewPort (0.3333, 0.0, 0.6666, 1.0, v2);
	viewer.createViewPort (0.6666, 0.0, 1.0, 1.0, v3);

	// The color we will be using
        float bckgr_gray_level = 1.0;  // Black
	float txt_gray_lvl = 1.0 - bckgr_gray_level;

	// Original point cloud is white
	pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> cloud_color_h (cloud, (int) 255 * txt_gray_lvl, (int) 255 * txt_gray_lvl,
		                                                               (int) 255 * txt_gray_lvl);
	viewer.addPointCloud (cloud, cloud_color_h, "cloud_v1", v1);

	pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> cloud_filtered_color_h (cloud_filtered, 20, 180, 20);  //blue
	viewer.addPointCloud (cloud_filtered, cloud_filtered_color_h, "cloud_filtered_v2", v2);
	pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> cloud_outtered_color_h (cloud_outtered, 180, 20, 20);  //read
	viewer.addPointCloud (cloud_outtered, cloud_outtered_color_h, "cloud_outtered_v3", v3);

	// Adding text descriptions in each viewport
        viewer.addText ("black: Original point cloud", 10, 15, 16, txt_gray_lvl, txt_gray_lvl, txt_gray_lvl, "statisticalFilter_info_1", v1);
        viewer.addText ("green: filtered point cloud", 10, 15, 16, txt_gray_lvl, txt_gray_lvl, txt_gray_lvl, "statisticalFilter_info_2", v2);
        viewer.addText ("rea: discrete points", 10, 15, 16, txt_gray_lvl, txt_gray_lvl, txt_gray_lvl, "statisticalFilter_info_3", v3);
	 
   	 
	// Set background color
	viewer.setBackgroundColor (bckgr_gray_level, bckgr_gray_level, bckgr_gray_level, v1);
	viewer.setBackgroundColor (bckgr_gray_level, bckgr_gray_level, bckgr_gray_level, v2);
	viewer.setBackgroundColor (bckgr_gray_level, bckgr_gray_level, bckgr_gray_level, v3);

	// Set camera position and orientation
	viewer.setCameraPosition (-3.68332, 2.94092, 5.71266, 0.289847, 0.921947, -0.256907, 0);
	viewer.setSize (1280, 1024);  // Visualiser window size

	 while (!viewer.wasStopped ()){
	 	 viewer.spinOnce (1000);
	 }

    return 0;
}
