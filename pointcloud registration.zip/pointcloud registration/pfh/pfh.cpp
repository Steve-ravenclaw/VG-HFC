#include <pcl/io/io.h>
#include <pcl/point_types.h>                  //点类型头文件
#include <pcl/features/pfh.h>                 //pfh特征估计类头文件
#include <pcl/common/io.h>
#include <pcl/io/pcd_io.h>  // 不要忘记
 #include <pcl/visualization/cloud_viewer.h>
#include <pcl/visualization/pcl_plotter.h>// 直方图的可视化 方法2

int main(int argc, char **argv){

    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZ>());
    pcl::PointCloud<pcl::PointXYZ>::Ptr keypoints(new pcl::PointCloud<pcl::PointXYZ>());
    pcl::PointCloud<pcl::Normal>::Ptr normals(new pcl::PointCloud<pcl::Normal>());
    pcl::PointCloud<pcl::PFHSignature125>::Ptr descriptors(new pcl::PointCloud<pcl::PFHSignature125>());

    if(argc < 4){
        std::cout << "exefile cloud keypoint normals " << endl;
        return -1;
    }
    
    //input sequence: cloud, keypoint, normals
    pcl::io::loadPCDFile (argv[1], *cloud);
    pcl::io::loadPCDFile (argv[2], *keypoints);
    pcl::io::loadPCDFile (argv[3], *normals);

    clock_t start = clock();

    //PFH estimation object.
    pcl::PFHEstimation<pcl::PointXYZ, pcl::Normal, pcl::PFHSignature125> pfh;

    //如果点云是类型为PointNormal,则执行pfh.setInputNormals (cloud);
    pfh.setInputCloud(keypoints);  // 计算keypoints处的特征
    pfh.setInputNormals(normals);   // cloud的法线
    
    //计算的平面是cloud 而不是keypoints,省略则默认计算平面为keypoints
    pfh.setSearchSurface(cloud); 

    //创建一个空的kd树表示法，并把它传递给PFH估计对象。
    pcl::search::KdTree<pcl::PointXYZ>::Ptr kdtree(new pcl::search::KdTree<pcl::PointXYZ> );
    pfh.setSearchMethod(kdtree);

    //注意：此处使用的半径必须要大于估计表面法线时使用的半径!!!
    //pfh.setRadiusSearch(1);//计算pfh特征值

    	
    if(argc > 4){
    	
        pfh.setKSearch(atoi(argv[4]));
    	
    }else{
    	
        pfh.setRadiusSearch(2);
    	
    }
    

    ////计算pfh特征值
    pfh.compute(*descriptors);
    
    pcl::io::savePCDFileASCII ("../pfh.pcd", *descriptors);

    clock_t end = clock();
    cout<<"Time pfh: "<< (double)(end - start) / CLOCKS_PER_SEC <<endl;
    cout<<"Get pfh size(): "<< descriptors->points.size()<<endl;

    //可视化直方图
    int num = 300;
    if(argc == 6){
      num = atoi(argv[5]);
    }
    pcl::visualization::PCLPlotter plotter;
    plotter.addFeatureHistogram(*descriptors, num); //设置的很坐标长度，该值越大，则显示的越细致
    
   while(!plotter.wasStopped()){
   	plotter.spinOnce(1000);   	
   }
   return 0;
}
