#include <pcl/registration/sample_consensus_prerejective.h>   // pose estimate
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <iostream>
// #include <eigen>


int main(int argc, char* argv[]){
    pcl::PointCloud<pcl::PointXYZ>::Ptr source_cloud( new pcl::PointCloud<pcl::PointXYZ>() );
    pcl::PointCloud<pcl::PointXYZ>::Ptr taget_cloud( new  pcl::PointCloud<pcl::PointXYZ>() );
    pcl::PointCloud<pcl::PFHSignature125>::Ptr source_descriptors(new pcl::PointCloud<pcl::PFHSignature125>());
    pcl::PointCloud<pcl::PFHSignature125>::Ptr taget_descriptors(new pcl::PointCloud<pcl::PFHSignature125>());
    pcl::PointCloud<pcl::PointXYZ>::Ptr aligned_cloud( new pcl::PointCloud<pcl::PointXYZ>() );

    if(argc < 5){
        printf ("\t%s .pcd .pcd .ICP_iterations .ICP_iterations 迭代次数 估计点数 匹配最近描述子 相似度阈值 内点的数量 允许的最大距离\n", argv[0]);
        PCL_ERROR ("Provide 4 file.\n");
        return (-1);
    }
    
    int num1 = 1000;
    int num2 = 3;
    int num3 = 5 ;
    float num4 = 0.01f;
    float num5 = 0.01f;
    float num6 = 10.0f;
    
    if(argc == 11){
    	num1 = atoi(argv[5]);
    	num2 = atoi(argv[6]);
    	num3 = atoi(argv[7]);
    	num4 = atof(argv[8]);
    	num5 = atof(argv[9]);
    	num6 = atof(argv[10]);
    }

    pcl::io::loadPCDFile (argv[1], *source_cloud);
    pcl::io::loadPCDFile (argv[2], *taget_cloud);
    pcl::io::loadPCDFile (argv[3], *source_descriptors);
    pcl::io::loadPCDFile (argv[4], *taget_descriptors);

    // Object for pose estimation.
    pcl::SampleConsensusPrerejective<pcl::PointXYZ, pcl::PointXYZ, pcl::PFHSignature125> pose;
    pose.setInputSource(source_cloud);
    pose.setInputTarget(taget_cloud);
    pose.setSourceFeatures(source_descriptors);
    pose.setTargetFeatures(taget_descriptors);

    
    pose.setMaximumIterations(num1);      // 迭代次数
    pose.setNumberOfSamples(num2);            // 估计6DOF需要3个点
    pose.setCorrespondenceRandomness(num3);   // 匹配最近的5个描述子
    pose.setSimilarityThreshold(num4);     // 相似度阈值  
    pose.setInlierFraction(num5);         //内点的数量
    pose.setMaxCorrespondenceDistance(num6);  //允许的最大距离

    

    pose.align(*aligned_cloud);
    pcl::PointCloud<pcl::PointXYZ>::Ptr trans_cloud( new  pcl::PointCloud<pcl::PointXYZ>() );


    if (pose.hasConverged())
    {
        Eigen::Matrix4f transformation = pose.getFinalTransformation();
        Eigen::Matrix3f rotation = transformation.block<3, 3>(0, 0);
        Eigen::Vector3f translation = transformation.block<3, 1>(0, 3);

        std::cout << "Transformation matrix:" << std::endl << std::endl;
        printf("\t\t    | %6.3f %6.3f %6.3f | \n", rotation(0, 0), rotation(0, 1), rotation(0, 2));
        printf("\t\tR = | %6.3f %6.3f %6.3f | \n", rotation(1, 0), rotation(1, 1), rotation(1, 2));
        printf("\t\t    | %6.3f %6.3f %6.3f | \n", rotation(2, 0), rotation(2, 1), rotation(2, 2));
        std::cout << std::endl;
        printf("\t\tt = < %0.3f, %0.3f, %0.3f >\n", translation(0), translation(1), translation(2));
    }
    else std::cout << "Did not converge." << std::endl;
    
    // Visualization
    pcl::visualization::PCLVisualizer viewer ("ICP demo");
    // Create two vertically separated viewports
    int v1 (0);
    int v2 (1);
    viewer.createViewPort (0.0, 0.0, 0.5, 1.0, v1);
    viewer.createViewPort (0.5, 0.0, 1.0, 1.0, v2);

    // The color we will be using
    float bckgr_gray_level = 1.0;  // Black
    float txt_gray_lvl = 1.0 - bckgr_gray_level;

    // Original point cloud is white
    pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> taget_cloud_color_h (taget_cloud, (int) 255 * txt_gray_lvl, (int) 255 * txt_gray_lvl,
                                                                               (int) 255 * txt_gray_lvl);
    viewer.addPointCloud (taget_cloud, taget_cloud_color_h, "taget_cloud_v1", v1);
    viewer.addPointCloud (taget_cloud, taget_cloud_color_h, "taget_cloud_v2", v2);
    viewer.setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 3, "taget_cloud_v1");
    viewer.setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 3, "taget_cloud_v2");


    // Transformed point cloud is green
    pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> source_cloud_color_h (source_cloud, 20, 180, 20);
    viewer.addPointCloud (source_cloud, source_cloud_color_h, "source_cloud_v1", v1);
    viewer.setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 3, "source_cloud_v1");

    // ICP aligned point cloud is red
    pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> aligned_cloud_color_h (aligned_cloud, 180, 20, 20);
    viewer.addPointCloud (aligned_cloud, aligned_cloud_color_h, "aligned_cloud_v2", v2);
    viewer.setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 3, "aligned_cloud_v2");

    // ICP aligned point cloud is red
//    pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ>trans_cloud_color_h (trans_cloud,0, 0, 255);
//    viewer.addPointCloud (trans_cloud, trans_cloud_color_h, "trans_cloud_v2", v2);
//    viewer.setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 5, "trans_cloud_v2");




    // Adding text descriptions in each viewport
    viewer.addText ("black: target point cloud\nGreen: Original point cloud", 10, 15, 16, txt_gray_lvl, txt_gray_lvl, txt_gray_lvl, "icp_info_1", v1);
    viewer.addText ("black: target point cloud\nRed: ransac aligned point cloud", 10, 15, 16, txt_gray_lvl, txt_gray_lvl, txt_gray_lvl, "icp_info_2", v2);

    // std::stringstream ss;
    // ss << iterations;
    // std::string iterations_cnt = "ransac iterations = " + ss.str ();
    // viewer.addText (iterations_cnt, 10, 60, 16, txt_gray_lvl, txt_gray_lvl, txt_gray_lvl, "iterations_cnt", v2);

    // Set background color
    viewer.setBackgroundColor (bckgr_gray_level, bckgr_gray_level, bckgr_gray_level, v1);
    viewer.setBackgroundColor (bckgr_gray_level, bckgr_gray_level, bckgr_gray_level, v2);

    // Set camera position and orientation
    viewer.setCameraPosition (-3.68332, 2.94092, 5.71266, 0.289847, 0.921947, -0.256907, 0);
    viewer.setSize (1280, 1024);  // Visualiser window size

    // Register keyboard callback :
    //viewer.registerKeyboardCallback (&keyboardEventOccurred, (void*) NULL);

    // Display the visualiser
    while (!viewer.wasStopped ())
    {
        viewer.spinOnce (1000);
    }
    return 0;
}


